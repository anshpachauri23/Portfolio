#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "a3.h"

void
show_word_matrix (char wordmat[MAXN][MAXN], int nrows, int ncols)
{
  printf ("Word Matrix (%d,%d)\n", nrows, ncols);
  int ii, jj;
  printf ("    ");
  for (jj=0; jj<ncols; jj++)
    printf ("%2d", jj);
  printf ("\n");
  for (ii=0; ii<nrows; ii++)
  {
    printf ("%2d: [", ii);
    for (jj=0; jj<ncols; jj++)
      printf("%c ", (char)wordmat[ii][jj]);
    printf ("]\n");
  }
}

void
print_ascii_codes ()
{
  int car;
  while ((car = getchar ()) != EOF)
  {
    printf ("%d ", car);
    if (car == '\n')
      printf ("\n");
  }
}

#ifdef USE_FGETS
void
filter (char * src, char * dst)
{
  int ii,jj;
  int len = strlen(src);
  for (ii=0,jj=0; ii<len; ii++)
    if (isalpha(src[ii]))
  {
    dst[jj++] = src[ii];
  }
  dst[jj] = '\0';
}

int 
read_word_matrix (char wordmat[MAXN][MAXN], int *nrows, int *ncols)
{
  scanf ("%d %d", nrows, ncols);
  printf ("%d %d\n", *nrows, *ncols);
  if (*nrows > MAXN)
    return -1;
  if (*ncols > MAXN)
    return -1;
  while (1){
    int car;
    car = getchar ();
    if (!isspace(car))
    {
      ungetc (car, stdin);
      break;
    }
  }
  int ii, jj;
  for (ii=0; ii<*nrows; ii++)
  {
    int car;
    printf ("Reading row %d...\n",ii);
    char temp[MAXN*2];
    char * ptr = fgets (temp, MAXN*2, stdin);
    filter (temp, &wordmat[ii][0]);
  }
  return 0;
}
#endif
