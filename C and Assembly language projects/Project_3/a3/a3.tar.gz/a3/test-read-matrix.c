#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "a3.h"

// Use this test harness to test the reading of the matrix of words from
// standard input. 
// If implementing your own version of read_word_matrix with character-by-character
// processing, you must do:
// make read-matrix.testplus
// cat input02.txt | ./read-matrix.testplus
int main ()
{
  char wordmat[MAXN][MAXN]; // wordmat = word matrix.
  int nrows, ncols;
  int input_err; // input in error: 0 = no error.
  input_err = read_word_matrix (wordmat, &nrows, &ncols);
  if (!input_err) 
    show_word_matrix (wordmat, nrows, ncols);
  else
    printf ("Error when reading matrix of words.\n");
  return 0;
}
