#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "a3.h"

// Process and test an entire input file.
// Use test harness with:
// make search-words.test
// cat someinput.txt | ./search-words.test
int main ()
{
  char wordmat[MAXN][MAXN]; // wordmat = word matrix.
  int nrows, ncols;
  int input_err; // input in error: 0 = no error.
  input_err = read_word_matrix (wordmat, &nrows, &ncols);
  if (!input_err) show_word_matrix (wordmat, nrows, ncols);
  search_words (wordmat, nrows, ncols);
  return 0;
}
