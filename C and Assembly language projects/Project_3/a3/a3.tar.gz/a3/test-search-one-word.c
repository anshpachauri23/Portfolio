#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "a3.h"


int main ()
{
  char wordmat[MAXN][MAXN]; // wordmat = word matrix.
  int nrows, ncols;
  int input_err; // input in error: 0 = no error.
  input_err = read_word_matrix (wordmat, &nrows, &ncols);
  if (!input_err) show_word_matrix (wordmat, nrows, ncols);
  // Input needle is hard-wired. Feel free to change the string to search.
  // Remember that the matrix of words was read from standard input.
  // You can create your own input test cases.
  // By default, this test-harness assumes input02.txt as the input.
  search_one_word (wordmat, nrows, ncols, "aaaa");
  return 0;
}
