#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "a3.h"

int test_case[][6] = {
  {4,4,0,0,-1,-1},
  {4,4,1,0,0,-1},
  {4,4,2,2,0,1},
  {4,4,3,3,0,-1},
  {4,4,2,2,1,-1},
  {4,4,3,0,1,0},
  {4,4,3,3,-1,0},
  {-1,-1,-1,-1,-1,-1},
};

// NOTE: This test harness only works with input02.txt
int main ()
{
  char wordmat[MAXN][MAXN]; // wordmat = word matrix.
  int nrows, ncols;
  int input_err; // input in error: 0 = no error.
  input_err = read_word_matrix (wordmat, &nrows, &ncols);
  if (!input_err) 
  {
    show_word_matrix (wordmat, nrows, ncols);
    char candidate[MAXN];
    char needle[MAXN];
    sprintf (needle,"%s","aaaa");
    int tc=0;
    while (test_case[tc][0] != -1) {
      int out;
      int row=test_case[tc][2];
      int col=test_case[tc][3];
      int dvrow=test_case[tc][4];
      int dvcol=test_case[tc][5];
      out = extract_word (wordmat, nrows, ncols, row, col, dvrow, dvcol, needle, candidate);
      printf ("Test case %d: center=[%d,%d], direction=[%d,%d], result= %d [%s]\n", tc, row, col, dvrow, dvcol, out, candidate);
      tc++;
    }
  }
  else
    printf ("Error when reading matrix of words.\n");
  return 0;
}
