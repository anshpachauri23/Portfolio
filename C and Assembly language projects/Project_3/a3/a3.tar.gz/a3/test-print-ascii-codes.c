#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "a3.h"

// Use this file to print input*.txt files in ASCII.
// This will give you an idea of the raw text encoding
// and of how to process the input character by character.
int main ()
{
  print_ascii_codes (); 
  return 0;
}
