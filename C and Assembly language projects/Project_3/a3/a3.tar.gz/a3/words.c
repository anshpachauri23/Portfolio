#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "a3.h"

#ifndef USE_FGETS
int 
read_word_matrix (char wordmat[MAXN][MAXN], int *nrows, int *ncols)
{
  int car;
  *nrows = 0;
  *ncols = 0;
  
  // Return 0 if no error occurred.
  return 0;
}
#endif


int
extract_word (char wordmat[MAXN][MAXN], // Matrix of words.
  int nrows, int ncols, // Number of rows and columns in the matrix of words.
  int ii, int jj, // Coordinates of starting cell.
  int di, int dj, // Direction along rows and columns. Each can be one of {-1,0,1}.
  char needle[MAXN], // String to search for.
  char candidate[MAXN]) // Extracted string from wordmat that starts at <row,col> and found along direction {-1,0,1}.
{


}


int
search_one_word (
  char wordmat[MAXN][MAXN], // Matrix of words to search in.
  int nrows, int ncols, // Size of matrix of words.
  char *needle) // String to search for in the matrix of words.
{


}



void
search_words (char wordmat[MAXN][MAXN], int nrows, int ncols)
{


  // Use the below line to print out the needle string and 
  // the number of matches found in the matrix of words.
  // printf ("search_words(%s) = %d\n", needle, matches);
}
