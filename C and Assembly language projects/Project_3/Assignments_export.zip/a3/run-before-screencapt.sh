#!/bin/bash

whoami
hostname
date
