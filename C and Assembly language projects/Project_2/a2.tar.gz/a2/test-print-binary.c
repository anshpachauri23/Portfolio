#include <stdio.h>
#include "a2.h"


int main ()
{
  print_in_binary (5);
  print_in_binary (10);
  print_in_binary ((15 << 8) + (15 << 16));

  return 0;
}
