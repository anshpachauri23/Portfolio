#ifndef A2_H
#define A2_H

extern
void
print_in_binary (unsigned int n);

extern
unsigned int count_bits (unsigned int pat);

extern
unsigned int count_bit_type (unsigned int num, unsigned int needle);

extern
unsigned int
invert_32bit (unsigned int nin);

extern
unsigned int 
find_pattern (unsigned int num, unsigned int pat);

extern
void translate_bits (char *);


#endif
