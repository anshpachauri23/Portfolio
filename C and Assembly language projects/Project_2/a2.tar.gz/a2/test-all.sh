#!/bin/bash

make clean

tests="count-bits count-bit-type find-pattern invert-32bit translate-bits"

for tc in $tests; do
  make $tc.test
  if [ ! -x $tc.test ]; then
    echo "Test binary for $tc not found. Fix before proceeding. Aborting ..."
    exit 42
  fi
  ./$tc.test
  echo 
  echo "---------------------------------------------------------------"
  echo
done

whoami
hostname
date
