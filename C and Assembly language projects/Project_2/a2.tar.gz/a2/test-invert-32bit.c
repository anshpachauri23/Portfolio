#include <stdio.h>
#include "a2.h"

void
test_one (unsigned int num)
{
  unsigned int new_val = invert_32bit (num);
  print_in_binary (num);
  print_in_binary (new_val);
  printf ("invert_32bit(%u) => %u\n", num, new_val);
}


int main ()
{
  printf ("Testing invert_32bit function...\n");
  /*
  Use the print_in_binary function to visually determine that your 
  output is correct.
  */
  test_one (15 << 16);
  test_one (15+32);
  test_one (196+32);
  test_one (255);

  return 0;
}
