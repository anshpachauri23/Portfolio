#include <stdio.h>
#include "a2.h"

void
test_one (unsigned int haystack, unsigned int needle)
{
  printf ("find_pattern(%u,%u): %u\n", haystack, needle, find_pattern(haystack, needle));
}


int main ()
{
  printf ("Testing find-pattern function...\n");
  /*
  These are some of the outputs you should be getting once your code works correctly.
  test_one (5,1) = 2
  test_one ((32+64)+(512+1024), 3) = 2
  test_one ((16+32+64)+(512+1024), 3) = 2
  test_one ((7<<20)+(7<<10)+(7<< 5), 7) = 3
  test_one ((5<<24)+(5<<15)+(5<< 10)+(5<<5), 5) = 4
  test_one ((15<<24)+(15<<15)+(15<< 10), 15) = 3
  test_one (511, 3) = 4
  */
  test_one (5,1);
  test_one ((32+64)+(512+1024), 3);
  test_one ((16+32+64)+(512+1024), 3);
  test_one ((7<<20)+(7<<10)+(7<< 5), 7);
  test_one ((5<<24)+(5<<15)+(5<< 10)+(5<<5), 5);
  test_one ((15<<24)+(15<<15)+(15<< 10), 15);
  test_one (511, 3);

  return 0;
}
