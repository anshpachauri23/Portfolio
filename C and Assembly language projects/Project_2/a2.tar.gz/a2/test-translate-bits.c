#include <stdio.h>
#include "a2.h"

void test_one (char * filename)
{
  printf ("Testing inputs in file %s...\n", filename);
  translate_bits (filename);
}


int main ()
{
  printf ("Testing find-pattern function...\n");
  /*
  These are some of the outputs you should be getting once your code works correctly.
  Testing inputs in file input1.txt...
translate_bits(testcase=1,haystack=51,needle=3,on_bits=3,matches=1) ==> 3342336
translate_bits(testcase=2,haystack=119,needle=7,on_bits=4,matches=2) ==> 7798784
translate_bits(testcase=3,haystack=239,needle=7,on_bits=6,matches=2) ==> 15663104
translate_bits(testcase=4,haystack=239,needle=7,on_bits=7,matches=2) ==> 15663104
translate_bits(testcase=5,haystack=239,needle=7,on_bits=8,matches=2) ==> 239
Testing inputs in file input2.txt...
translate_bits(testcase=1,haystack=660,needle=5,on_bits=3,matches=2) ==> 43253760
translate_bits(testcase=2,haystack=660,needle=5,on_bits=2,matches=3) ==> 660
Testing inputs in file input3.txt...
translate_bits(testcase=1,haystack=1638,needle=3,on_bits=5,matches=3) ==> 107347968
translate_bits(testcase=2,haystack=1638,needle=3,on_bits=5,matches=4) ==> 1638
translate_bits(testcase=3,haystack=1638,needle=3,on_bits=7,matches=2) ==> 1638

  */

  test_one ("input1.txt");
  test_one ("input2.txt");
  test_one ("input3.txt");

  return 0;
}
