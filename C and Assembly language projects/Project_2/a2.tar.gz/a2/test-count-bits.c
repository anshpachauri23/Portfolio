#include <stdio.h>
#include "a2.h"

void
test_one (int num)
{
  printf ("count_bits(%u): %u\n", num, count_bits(num));
}


int main ()
{
  printf ("Testing count-bits function...\n");
  /*
  These are some of the outputs you should be getting once your code works correctly.
  count_bits(1): 1
  count_bits(5): 3
  count_bits(3): 2
  count_bits(8): 4
  count_bits(7): 3
  count_bits(32767): 15
  */
  test_one (1);
  test_one (5);
  test_one (3);
  test_one (8);
  test_one (7);
  test_one (32768-1);


  return 0;
}
