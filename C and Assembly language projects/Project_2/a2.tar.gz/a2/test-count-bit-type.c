#include <stdio.h>
#include "a2.h"

void
test_one (unsigned int haystack, unsigned int needle)
{
  printf ("count_bit_type(%d,%d) => (%d)\n", haystack, needle, count_bit_type (haystack, needle));
}


int main ()
{
  printf ("Testing count_bit_type function...\n");
  /*
  These are some of the outputs you should be getting once your code works correctly.
  count_bit_type(0,0) => (32)
  count_bit_type(0,1) => (0)
  count_bit_type(6,0) => (30)
  count_bit_type(6,1) => (2)
  count_bit_type(255,1) => (8)
  count_bit_type(255,0) => (24)
  count_bit_type(9184,1) => (6)
  */
  test_one (0,0);
  test_one (0,1);
  test_one (6,0);
  test_one (6,1);
  test_one (255,1);
  test_one (255,0);
  test_one (8192+768+128+96,1);

  return 0;
}
