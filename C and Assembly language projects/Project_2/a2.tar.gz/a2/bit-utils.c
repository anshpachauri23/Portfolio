#include <stdio.h>
#include "a2.h"

void
print_in_binary (unsigned int n)
{
  unsigned int div = 1;
  unsigned nbits = 1;
  while ((div << 1) < n) {
    div = div << 1;
    nbits ++;
  }


  printf ("%u ==> ", n);
  int ii;
  for (ii = 0; ii < 32 - nbits; ii++) {
    if (ii % 8 == 0)
      printf ("| ");
    printf ("0 ");
  }

  while (1)
  {
    unsigned int digit = n / div;
    if (ii % 8 == 0)
      printf ("| ");
    printf ("%d ", digit);
    n = n % div;
    div = div / 2;
    ii++;
    if (div == 0)
      break;
  }
  printf ("\n");
}
